#!/bin/bash
echo 'What is the Date'
read $1
echo 'What is the Time'
read $2
cat $1_Dealer_schedule | awk -F" " '{print $1, $2, $5,$6}'| grep $2 
